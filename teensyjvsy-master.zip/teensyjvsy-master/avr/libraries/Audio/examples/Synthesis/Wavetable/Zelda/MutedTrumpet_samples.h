#pragma once
#include <Audio.h>
extern const AudioSynthWavetable::instrument_data MutedTrumpet;

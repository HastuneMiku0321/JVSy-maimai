extern const unsigned int guitar_e4_note[52184];

//  Teensy 2.0 does not have SPIFIFO.  This file exists so libraries
//  may use #include "SPIFIFO.h", and then test for HAS_SPIFIFO

// For compatibility with some ESP8266 programs
#include <avr/pgmspace.h>
